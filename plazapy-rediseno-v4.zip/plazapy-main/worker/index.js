// PlazaPY · Worker de Cloudflare
// Entrega las páginas de producto, anuncio y tienda con el título, la descripción y la foto
// ya escritos en el HTML, para que WhatsApp, Facebook, Telegram, etc. muestren una vista
// previa linda al pegar el link (esas apps no ejecutan JavaScript).
// Todo lo demás se sirve igual que antes, como archivo estático.

const SITIO = 'https://www.plazapy.com';
const IMAGEN_DEFECTO = SITIO + '/icon-512.png';

const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const gs = (n) => 'Gs. ' + String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const resumen = (t, max = 160) => {
  const s = String(t || '').replace(/\s+/g, ' ').trim();
  return s.length > max ? s.slice(0, max - 1).trimEnd() + '…' : s;
};

function primeraFoto(r) {
  let fotos = [];
  try { fotos = r.fotos_urls ? JSON.parse(r.fotos_urls) : []; } catch (_) { /* sin fotos extra */ }
  const url = r.foto_url || fotos[0] || r.logo_url || r.banner_url || '';
  return /^https:\/\//i.test(url) ? url : IMAGEN_DEFECTO;
}

// Qué tabla consultar y cómo armar la vista previa de cada página
const PAGINAS = {
  producto: {
    tabla: 'productos',
    select: 'nombre,descripcion,precio,precio_oferta,foto_url,fotos_urls,tiendas(nombre)',
    filtro: 'estado=eq.aprobado',
    tipo: 'product',
    armar: (r) => ({
      title: `${r.nombre} — PlazaPY`,
      desc: resumen(`${gs(r.precio_oferta || r.precio)}${r.tiendas && r.tiendas.nombre ? ' · ' + r.tiendas.nombre : ''}. ${r.descripcion || ''}`),
      image: primeraFoto(r),
    }),
  },
  detalle: {
    tabla: 'anuncios',
    select: 'titulo,descripcion,precio,foto_url,fotos_urls,categoria,subcategoria,ciudad,barrio',
    filtro: 'estado=eq.aprobado',
    tipo: 'website',
    armar: (r) => {
      const alquiler = r.categoria === 'inmuebles' && /alquiler/i.test(r.subcategoria || '');
      const lugar = [r.barrio, r.ciudad].filter(Boolean).join(', ');
      return {
        title: `${r.titulo} — PlazaPY`,
        desc: resumen(`${gs(r.precio)}${alquiler ? ' / mes' : ''}${lugar ? ' · ' + lugar : ''}. ${r.descripcion || ''}`),
        image: primeraFoto(r),
      };
    },
  },
  tienda: {
    tabla: 'tiendas',
    select: 'nombre,descripcion,logo_url,banner_url,ciudad',
    filtro: 'estado=eq.activa',
    tipo: 'website',
    armar: (r) => ({
      title: `${r.nombre} — Tienda en PlazaPY`,
      desc: resumen(r.descripcion || `Tienda en PlazaPY${r.ciudad ? ', ' + r.ciudad : ''}. Mirá sus productos y pedí con delivery.`),
      image: primeraFoto(r),
    }),
  },
};

async function consultar(env, cfg, id) {
  const base = env.SUPABASE_URL || 'https://ayjlnbxcojqglcufqzob.supabase.co';
  const url = `${base}/rest/v1/${cfg.tabla}?id=eq.${encodeURIComponent(id)}&${cfg.filtro}&select=${encodeURIComponent(cfg.select)}&limit=1`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  try {
    const r = await fetch(url, {
      headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: `Bearer ${env.SUPABASE_ANON_KEY}` },
      signal: ctrl.signal,
    });
    if (!r.ok) { console.log('Supabase respondió', r.status); return null; }
    const filas = await r.json();
    return Array.isArray(filas) && filas.length ? filas[0] : null;
  } catch (err) {
    console.log('consulta fallida:', String(err));
    return null; // si Supabase tarda o falla, se sirve la página normal
  } finally {
    clearTimeout(timer);
  }
}

// Cloudflare sirve /producto.html como /producto; probamos ambas formas
async function cargarPagina(env, nombre) {
  for (const ruta of [`/${nombre}`, `/${nombre}.html`]) {
    let r = await env.ASSETS.fetch(new Request(SITIO + ruta));
    if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
      r = await env.ASSETS.fetch(new Request(new URL(r.headers.get('location'), SITIO).toString()));
    }
    if (r.ok) return r;
  }
  return null;
}

function etiquetas(cfg, datos, urlCanonica) {
  const t = esc(datos.title), d = esc(datos.desc), i = esc(datos.image), u = esc(urlCanonica);
  return `
<meta name="description" content="${d}">
<link rel="canonical" href="${u}" id="canonical">
<meta property="og:site_name" content="PlazaPY">
<meta property="og:type" content="${cfg.tipo}">
<meta property="og:title" content="${t}" id="ogTitle">
<meta property="og:description" content="${d}" id="ogDesc">
<meta property="og:image" content="${i}" id="ogImage">
<meta property="og:url" content="${u}" id="ogUrl">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${t}" id="twTitle">
<meta name="twitter:description" content="${d}" id="twDesc">
<meta name="twitter:image" content="${i}" id="twImage">
`;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const nombre = url.pathname.replace(/^\/+|\/+$/g, '').replace(/\.html$/, '');
    const cfg = PAGINAS[nombre];
    const id = url.searchParams.get('id');

    const esLectura = request.method === 'GET' || request.method === 'HEAD';
    if (!cfg || !esLectura || !id || !/^[\w-]{1,64}$/.test(id)) {
      return env.ASSETS.fetch(request);
    }

    const [pagina, fila] = await Promise.all([cargarPagina(env, nombre), consultar(env, cfg, id)]);
    if (!pagina) return env.ASSETS.fetch(request);
    if (!fila) return pagina; // no existe o no está aprobado: la página muestra su propio aviso

    const datos = cfg.armar(fila);
    const canonica = `${SITIO}/${nombre}.html?id=${encodeURIComponent(id)}`;
    const nuevo = new HTMLRewriter()
      .on('title', { element(e) { e.setInnerContent(datos.title); } })
      .on('meta[name="description"], meta[property^="og:"], meta[name^="twitter:"], link[rel="canonical"]', { element(e) { e.remove(); } })
      .on('head', { element(e) { e.append(etiquetas(cfg, datos, canonica), { html: true }); } })
      .transform(pagina);

    const headers = new Headers(nuevo.headers);
    headers.set('content-type', 'text/html; charset=utf-8');
    headers.delete('location');
    return new Response(request.method === 'HEAD' ? null : nuevo.body, { status: 200, headers });
  },
};
