// Edge Function: envía avisos por WhatsApp (CallMeBot) al administrador.
// La invocan los triggers de la base de datos (no el navegador), así la clave nunca sale del servidor.
//
// Secrets necesarios (Supabase → Edge Functions → Secrets):
//   WEBHOOK_SECRET     clave larga; la misma que pusiste en los triggers del SQL 02
//   CALLMEBOT_PHONE    ej. 595995676743
//   CALLMEBOT_APIKEY   tu apikey de CallMeBot
// SUPABASE_URL y SUPABASE_SERVICE_ROLE_KEY ya vienen incluidas.
//
// IMPORTANTE: desplegar SIN verificación JWT (la autenticación es el x-webhook-secret):
//   supabase functions deploy notificar-admin --no-verify-jwt
//   (en el panel web: desactivar "Verify JWT" en la función)

import { createClient } from "jsr:@supabase/supabase-js@2";

const WEBHOOK_SECRET = Deno.env.get("WEBHOOK_SECRET");
const PHONE = Deno.env.get("CALLMEBOT_PHONE");
const APIKEY = Deno.env.get("CALLMEBOT_APIKEY");
const sb = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const gs = (n: unknown) => "Gs. " + Number(n || 0).toLocaleString("es-PY");
const t = (v: unknown, max = 120) => String(v ?? "-").slice(0, max);

async function nombreDe(tabla: string, id: unknown): Promise<string> {
  if (!id) return "-";
  const { data } = await sb.from(tabla).select("nombre").eq("id", id).maybeSingle();
  return t(data?.nombre);
}

function construirMensaje(tabla: string, r: Record<string, unknown>): Promise<string | null> | string | null {
  switch (tabla) {
    case "tiendas":
      return `🏪 NUEVA TIENDA pendiente de aprobación:\n\n${t(r.nombre)}\nWhatsApp: ${t(r.whatsapp)}\nCiudad: ${t(r.ciudad)}\n\nRevisar en plazapy.com/admin.html`;
    case "productos":
      return (async () =>
        `📦 NUEVO PRODUCTO pendiente de aprobación:\n\n${t(r.nombre)}\nTienda: ${await nombreDe("tiendas", r.tienda_id)}\nPrecio: ${gs(r.precio)}\n\nRevisar en plazapy.com/admin.html`)();
    case "pagos":
      return (async () =>
        `💳 NUEVO COMPROBANTE de pago:\n\nTienda: ${await nombreDe("tiendas", r.tienda_id)}\nPlan: ${t(r.plan_codigo)} (${gs(r.monto_gs)})\n\nAprobar en plazapy.com/admin.html → Pagos`)();
    case "pedidos":
      // Solo avisamos los pedidos con envío (los de retiro en tienda no te competen)
      if (r.tipo_entrega === "retiro") return null;
      return (async () =>
        `🚚 PEDIDO CON ENVÍO:\n\nProducto: ${await nombreDe("productos", r.producto_id)} x${t(r.cantidad, 6)}\nTotal: ${gs(r.total)}\nEnvío: ${r.tipo_entrega === "asuncion" ? "Asunción" : "Gran Asunción"} (${gs(r.costo_delivery)})\n\nCliente: ${t(r.nombre_cliente)} - ${t(r.whatsapp_cliente, 30)}\nDirección: ${t(r.direccion_entrega)}, ${t(r.ciudad_entrega)}${r.barrio_entrega ? " - " + t(r.barrio_entrega) : ""}\nTienda: ${await nombreDe("tiendas", r.tienda_id)}`)();
    default:
      return null;
  }
}

Deno.serve(async (req) => {
  if (!WEBHOOK_SECRET || req.headers.get("x-webhook-secret") !== WEBHOOK_SECRET) {
    return new Response("forbidden", { status: 403 });
  }
  let payload: { type?: string; table?: string; record?: Record<string, unknown> };
  try {
    payload = await req.json();
  } catch {
    return new Response("bad request", { status: 400 });
  }
  if (payload.type !== "INSERT" || !payload.record || !payload.table) {
    return new Response("ignored");
  }

  const msg = await construirMensaje(payload.table, payload.record);
  if (!msg) return new Response("ignored");
  if (!PHONE || !APIKEY) return new Response("missing callmebot secrets", { status: 500 });

  const url = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(PHONE)}&text=${encodeURIComponent(msg)}&apikey=${encodeURIComponent(APIKEY)}`;
  const r = await fetch(url);
  return new Response(r.ok ? "ok" : "callmebot error", { status: r.ok ? 200 : 502 });
});
