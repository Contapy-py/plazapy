-- =====================================================================
-- PlazaPY · Fase 1b
--  A) Productos destacados solo con plan vigente (reforzado en la base)
--  B) Vencimiento automático de destacados
--  C) Notificaciones al admin desde el servidor (reemplaza CallMeBot en el navegador)
-- Ejecutar DESPUÉS de 01_fase1_pagos_planes.sql
-- =====================================================================

-- 0) Precio de lanzamiento (por si ya habías ejecutado el 01 con otro valor)
update public.planes set precio_gs = 30000 where codigo = 'destacado';

-- A) Una tienda sin plan Destacado vigente no puede marcar productos como destacados.
--    El admin sí puede. Si no corresponde, se desmarca en silencio (no bloquea la edición).
create or replace function public.limitar_producto_destacado()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  if new.destacado and auth.uid() is not null and not public.es_admin() then
    if not exists (
      select 1 from public.tiendas t
       where t.id = new.tienda_id
         and t.destacada
         and (t.destacada_hasta is null or t.destacada_hasta > now())
    ) then
      new.destacado := false;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_limitar_producto_destacado on public.productos;
create trigger trg_limitar_producto_destacado before insert or update on public.productos
  for each row execute function public.limitar_producto_destacado();

-- B) Vencimiento: apaga la tienda destacada vencida y los productos destacados de esa tienda
create or replace function public.vencer_destacados()
returns void language plpgsql security definer
set search_path = public
as $$
declare ids uuid[];
begin
  with v as (
    update public.tiendas set destacada = false
     where destacada and destacada_hasta is not null and destacada_hasta < now()
    returning id
  )
  select array_agg(id) into ids from v;

  if ids is not null then
    update public.productos set destacado = false where tienda_id = any(ids) and destacado;
  end if;
end $$;
revoke all on function public.vencer_destacados() from public, anon, authenticated;

-- Programarlo cada día (activá pg_cron en Database → Extensions y descomentá):
-- select cron.schedule('vencer-destacados', '5 3 * * *', $$ select public.vencer_destacados() $$);

-- C) Avisos al admin: un trigger por tabla llama a la Edge Function "notificar-admin".
--    1) Reemplazá CAMBIAR_ESTE_SECRETO por una clave larga y aleatoria (la misma que usarás
--       en el secret WEBHOOK_SECRET de la función).
--    2) Si da error "schema supabase_functions does not exist", activá
--       Database → Webhooks → "Enable webhooks" y volvé a ejecutar.
drop trigger if exists notif_admin_tiendas   on public.tiendas;
drop trigger if exists notif_admin_productos on public.productos;
drop trigger if exists notif_admin_pagos     on public.pagos;
drop trigger if exists notif_admin_pedidos   on public.pedidos;

create trigger notif_admin_tiendas after insert on public.tiendas
  for each row execute function supabase_functions.http_request(
    'https://ayjlnbxcojqglcufqzob.supabase.co/functions/v1/notificar-admin', 'POST',
    '{"Content-Type":"application/json","x-webhook-secret":"CAMBIAR_ESTE_SECRETO"}', '{}', '5000');

create trigger notif_admin_productos after insert on public.productos
  for each row execute function supabase_functions.http_request(
    'https://ayjlnbxcojqglcufqzob.supabase.co/functions/v1/notificar-admin', 'POST',
    '{"Content-Type":"application/json","x-webhook-secret":"CAMBIAR_ESTE_SECRETO"}', '{}', '5000');

create trigger notif_admin_pagos after insert on public.pagos
  for each row execute function supabase_functions.http_request(
    'https://ayjlnbxcojqglcufqzob.supabase.co/functions/v1/notificar-admin', 'POST',
    '{"Content-Type":"application/json","x-webhook-secret":"CAMBIAR_ESTE_SECRETO"}', '{}', '5000');

create trigger notif_admin_pedidos after insert on public.pedidos
  for each row execute function supabase_functions.http_request(
    'https://ayjlnbxcojqglcufqzob.supabase.co/functions/v1/notificar-admin', 'POST',
    '{"Content-Type":"application/json","x-webhook-secret":"CAMBIAR_ESTE_SECRETO"}', '{}', '5000');
