-- =====================================================================
-- PlazaPY · Fase 1 · Planes + pagos con comprobante + aprobación 1 clic
-- Ejecutar completo en Supabase → SQL Editor (una sola vez).
-- Supuestos: tiendas.id es uuid y existe perfiles(id, es_admin).
-- =====================================================================

-- 1) Helper: ¿el usuario actual es admin?
create or replace function public.es_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select coalesce((select es_admin from public.perfiles where id = auth.uid()), false);
$$;

-- 2) Catálogo de planes (fuente única de precios)
create table if not exists public.planes (
  codigo        text primary key,          -- 'destacado'
  nombre        text not null,
  precio_gs     integer not null,
  duracion_dias integer,                   -- null = pago único (permanente)
  descripcion   text,                      -- beneficios separados por |
  activo        boolean not null default true,
  orden         integer not null default 0
);

insert into public.planes (codigo, nombre, precio_gs, duracion_dias, descripcion, orden) values
  ('destacado',  'Destacado',  30000, 30,  'Aparecés primero en tiendas y en el inicio|Insignia ⭐ visible para compradores|Podés destacar tus productos', 1)
on conflict (codigo) do nothing;
-- Cambiá los precios cuando quieras:  update planes set precio_gs = 80000 where codigo = 'destacado';

alter table public.planes enable row level security;
drop policy if exists planes_lectura on public.planes;
create policy planes_lectura on public.planes for select using (true);
drop policy if exists planes_admin on public.planes;
create policy planes_admin on public.planes for all using (public.es_admin()) with check (public.es_admin());

-- 3) Pagos (comprobantes enviados por las tiendas)
create table if not exists public.pagos (
  id               uuid primary key default gen_random_uuid(),
  tienda_id        uuid not null references public.tiendas(id) on delete cascade,
  plan_codigo      text not null references public.planes(codigo),
  monto_gs         integer,                -- lo fija el trigger según el plan
  comprobante_path text not null,
  estado           text not null default 'pendiente' check (estado in ('pendiente','aprobado','rechazado')),
  nota_admin       text,
  created_at       timestamptz not null default now(),
  revisado_at      timestamptz
);
create index if not exists pagos_estado_idx on public.pagos (estado, created_at desc);
create index if not exists pagos_tienda_idx on public.pagos (tienda_id);

-- El monto SIEMPRE sale de la tabla planes (la tienda no puede elegirlo)
create or replace function public.pagos_fijar_monto()
returns trigger language plpgsql as $$
begin
  select precio_gs into new.monto_gs from public.planes where codigo = new.plan_codigo;
  new.estado := 'pendiente';
  return new;
end $$;
drop trigger if exists trg_pagos_fijar_monto on public.pagos;
create trigger trg_pagos_fijar_monto before insert on public.pagos
  for each row execute function public.pagos_fijar_monto();

alter table public.pagos enable row level security;
drop policy if exists pagos_select on public.pagos;
create policy pagos_select on public.pagos for select using (
  public.es_admin() or tienda_id in (select id from public.tiendas where user_id = auth.uid())
);
drop policy if exists pagos_insert on public.pagos;
create policy pagos_insert on public.pagos for insert with check (
  tienda_id in (select id from public.tiendas where user_id = auth.uid())
);
-- No hay policy de update/delete: los pagos solo se resuelven con resolver_pago()

-- 4) Bucket PRIVADO para comprobantes (carpeta = id de la tienda)
insert into storage.buckets (id, name, public) values ('comprobantes', 'comprobantes', false)
on conflict (id) do nothing;

drop policy if exists comprobantes_subir on storage.objects;
create policy comprobantes_subir on storage.objects for insert to authenticated with check (
  bucket_id = 'comprobantes'
  and (storage.foldername(name))[1] in (select id::text from public.tiendas where user_id = auth.uid())
);
drop policy if exists comprobantes_ver on storage.objects;
create policy comprobantes_ver on storage.objects for select to authenticated using (
  bucket_id = 'comprobantes'
  and (public.es_admin()
       or (storage.foldername(name))[1] in (select id::text from public.tiendas where user_id = auth.uid()))
);

-- 5) Aprobar / rechazar con un clic (solo admin)
--    Destacado: suma los días; si ya estaba vigente, extiende desde el vencimiento actual (renovación).
create or replace function public.resolver_pago(p_pago uuid, p_aprobar boolean, p_nota text default null)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v    public.pagos%rowtype;
  pl   public.planes%rowtype;
  base timestamptz;
begin
  if not public.es_admin() then raise exception 'No autorizado'; end if;

  select * into v from public.pagos where id = p_pago for update;
  if not found then raise exception 'El pago no existe'; end if;
  if v.estado <> 'pendiente' then raise exception 'El pago ya fue resuelto'; end if;

  if p_aprobar then
    select * into pl from public.planes where codigo = v.plan_codigo;
    if v.plan_codigo = 'destacado' then
      select greatest(now(), coalesce(destacada_hasta, now())) into base from public.tiendas where id = v.tienda_id;
      update public.tiendas
         set destacada = true,
             destacada_hasta = base + make_interval(days => coalesce(pl.duracion_dias, 30)),
             plan_solicitado = null
       where id = v.tienda_id;
    else
      raise exception 'Plan no disponible';
    end if;
    update public.pagos set estado = 'aprobado', revisado_at = now(), nota_admin = p_nota where id = p_pago;
  else
    update public.pagos set estado = 'rechazado', revisado_at = now(), nota_admin = p_nota where id = p_pago;
    update public.tiendas set plan_solicitado = null where id = v.tienda_id;
  end if;
end $$;
revoke all on function public.resolver_pago(uuid, boolean, text) from public, anon;
grant execute on function public.resolver_pago(uuid, boolean, text) to authenticated;

-- 6) Seguridad: una tienda NO puede darse a sí misma destacada desde la consola
create or replace function public.proteger_campos_plan()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not public.es_admin() then
    if new.destacada is distinct from old.destacada
       or new.destacada_hasta is distinct from old.destacada_hasta
       or new.verificado is distinct from old.verificado then
      raise exception 'Solo un administrador puede cambiar el plan de la tienda';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_proteger_campos_plan on public.tiendas;
create trigger trg_proteger_campos_plan before update on public.tiendas
  for each row execute function public.proteger_campos_plan();

-- 7) OPCIONAL · vencimiento automático diario (activar pg_cron en Database → Extensions)
-- select cron.schedule('vencer-destacados', '5 3 * * *',
--   $$ update public.tiendas set destacada = false
--      where destacada and destacada_hasta is not null and destacada_hasta < now() $$);
