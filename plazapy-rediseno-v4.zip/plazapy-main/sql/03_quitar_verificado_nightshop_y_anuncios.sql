-- =====================================================================
-- PlazaPY · Fase 2
--  A) Se elimina el plan "Verificado"
--  B) Se oculta todo el contenido de NightShop (productos para adultos)
--  C) El administrador puede aprobar / destacar / eliminar anuncios
-- Ejecutar DESPUÉS de 01 y 02, en Supabase → SQL Editor.
-- =====================================================================

-- A) Plan Verificado fuera de servicio
--    (se conserva la fila, desactivada, para no romper el historial de pagos)
update public.pagos
   set estado = 'rechazado', nota_admin = 'Plan descontinuado', revisado_at = now()
 where plan_codigo = 'verificado' and estado = 'pendiente';

update public.tiendas set plan_solicitado = null where plan_solicitado = 'verificado';
update public.planes  set activo = false where codigo = 'verificado';

create or replace function public.resolver_pago(p_pago uuid, p_aprobar boolean, p_nota text default null)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v    public.pagos%rowtype;
  pl   public.planes%rowtype;
  base timestamptz;
begin
  if not public.es_admin() then raise exception 'No autorizado'; end if;

  select * into v from public.pagos where id = p_pago for update;
  if not found then raise exception 'El pago no existe'; end if;
  if v.estado <> 'pendiente' then raise exception 'El pago ya fue resuelto'; end if;

  if p_aprobar then
    select * into pl from public.planes where codigo = v.plan_codigo;
    if v.plan_codigo = 'destacado' then
      select greatest(now(), coalesce(destacada_hasta, now())) into base from public.tiendas where id = v.tienda_id;
      update public.tiendas
         set destacada = true,
             destacada_hasta = base + make_interval(days => coalesce(pl.duracion_dias, 30)),
             plan_solicitado = null
       where id = v.tienda_id;
    else
      raise exception 'Plan no disponible';
    end if;
    update public.pagos set estado = 'aprobado', revisado_at = now(), nota_admin = p_nota where id = p_pago;
  else
    update public.pagos set estado = 'rechazado', revisado_at = now(), nota_admin = p_nota where id = p_pago;
    update public.tiendas set plan_solicitado = null where id = v.tienda_id;
  end if;
end $$;

-- B) NightShop: primero revisá cuántos productos hay...
select categoria, count(*) as productos
  from public.productos
 where categoria in ('juguetes-adultos','lenceria','cosmetica-adultos','disfraces','accesorios-adultos','parejas','adultos')
 group by categoria;

--    ...y se ocultan (se pueden recuperar cambiando el estado más adelante)
update public.productos
   set estado = 'rechazado', disponible = false, destacado = false
 where categoria in ('juguetes-adultos','lenceria','cosmetica-adultos','disfraces','accesorios-adultos','parejas','adultos');

--    Si preferís borrarlos de forma definitiva, descomentá:
-- delete from public.productos
--  where categoria in ('juguetes-adultos','lenceria','cosmetica-adultos','disfraces','accesorios-adultos','parejas','adultos');

-- C) El administrador gestiona anuncios (inmuebles y vehículos).
--    Si la tabla ya permitía esto, esta política simplemente no cambia nada.
drop policy if exists anuncios_admin_total on public.anuncios;
create policy anuncios_admin_total on public.anuncios
  for all using (public.es_admin()) with check (public.es_admin());
